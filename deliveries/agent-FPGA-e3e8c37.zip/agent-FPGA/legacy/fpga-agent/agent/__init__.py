"""RTL competition entrypoint package."""
